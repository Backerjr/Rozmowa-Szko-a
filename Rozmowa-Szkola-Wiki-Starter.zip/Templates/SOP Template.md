# SOP (Standard Operating Procedure) Template

**Process:**  
**Owner:**  
**Goal:**  

## Steps
1.
2.
3.

## Inputs
-

## Outputs / Definition of Done
-
