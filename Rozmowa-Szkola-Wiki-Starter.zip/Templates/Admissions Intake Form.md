# Admissions Intake Form (Template)

**Name:**  
**Contact:**  
**Age group:** Adult / Teen / 50+  
**Goal:** conversation / exam / work / travel  
**Availability:** days + times  
**Notes:** special needs, preferences
