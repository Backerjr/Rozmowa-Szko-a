# Meeting Notes (Template)

**Date:**  
**People:**  
**Goal:**  

## Notes
-

## Decisions
-

## Tasks (owner → due)
- [ ]  …
