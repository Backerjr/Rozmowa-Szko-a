# Admissions & Pricing

**Path**
1. Lead → [[Admissions Intake Form]] → Placement (15')
2. Offer: Starter Pack / Group / Exam Sprint
3. Confirm schedule & payment
4. Onboard: attendance + streak

**Pricing (example placeholders)**
- Starter Pack 4×60' — PLN ___
- Adults group monthly — PLN ___
- Exam Sprint (8 weeks) — PLN ___
- 1–1 coaching (60') — PLN ___

**Discounts**
- Buddy Pass −10% (both)
- Family Bundle −15% (2nd member)
