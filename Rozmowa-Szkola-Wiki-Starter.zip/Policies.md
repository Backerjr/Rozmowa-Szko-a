# Policies

**Attendance**: Please notify 24h in advance.  
**Make-ups**: Subject to availability (group flow prioritized).  
**Payments**: Upfront monthly or per package.  
**Refunds**: Non-refundable after package start, except legal requirements.  
**Privacy**: No publishing of student data without written consent.
