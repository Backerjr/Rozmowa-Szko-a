# Marketing Playbook

See also the external doc: 90-day plan (Notion one-pager).

**Pillars**
- No-Stress English (phrases)
- Student Wins (consent)
- Behind-the-Scenes (coffee/crafts)
- Exam Hacks (weekly)

**Weekly Rhythm**
- Mon: phrase Reel
- Wed: win/story
- Fri: exam tip
- Sun: timetable + RSVP (Crafts)

**KPIs**
- Leads/week ≥ 25
- Lead→Trial ≥ 40%
- Trial→Enroll ≥ 50%
- CPL ≤ PLN 15–25
