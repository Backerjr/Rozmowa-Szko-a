# Courses & Offers

- **Starter Pack (4×60')** — low-risk on-ramp.
- **Adults Groups (A0–B1)** — conversation + confidence.
- **Exam Sprint (8 weeks)** — ósmoklasisty/matura tasks, weekly mocks.
- **1–1 Coaching** — targeted goals.
- **Conversation & Crafts Night (2h)** — 60' talk + 60' hands-on.

See also: [[Admissions & Pricing]].
