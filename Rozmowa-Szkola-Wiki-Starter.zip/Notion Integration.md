# Notion Integration

**Pages**
- 90-Day Plan (one-pager)
- CRM Board (Kanban)
- Templates (Lead / Trial / Enroll)

**Buttons (/template)**
- New Lead → creates checklist
- Move to Trial → creates trial plan
- Enroll (Paid) → creates week-1 plan
