# Contributing

Thanks for improving the ROZMOWA wiki!

**How to edit**
- Keep pages short and practical.
- Prefer checklists and examples over theory.
- Link related pages with `[[Page Name]]`.

**Style**
- Friendly, clear, supportive.
- Polish first when addressing students; English OK for internal notes.
