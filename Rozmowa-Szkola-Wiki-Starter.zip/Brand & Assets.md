# Brand & Assets

**Voice:** friendly, supportive, zero-stress.  
**Tagline:** “Mów naturalnie. Czuj się swobodnie.”  
**Visuals:** cozy, human, warm light; avoid stocky clichés.

**Assets (add links)**
- Logo (PNG/SVG)
- Space photos
- Reels templates
- Flyer with QR→WhatsApp
