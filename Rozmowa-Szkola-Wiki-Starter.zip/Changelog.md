# Changelog

- 2025-09-26: Initial wiki created (structure + baseline pages).
