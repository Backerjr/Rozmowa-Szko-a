# CRM Workflow

**Stages**: Lead → Trial → Active → Frozen → Alumni

**Lead Card (properties)**
- Audience (Adult/Teen/SME)
- Source (IG/FB/GBP/Referral)
- Offer Path (Placement/Starter/Exam)
- Owner
- Status

**Automation**
- WhatsApp quick replies
- Booking + payments
- Zapier to Notion DB
