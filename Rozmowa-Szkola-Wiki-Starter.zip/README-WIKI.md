# ROZMOWA Wiki

This folder contains Markdown pages suitable for a GitHub Wiki.

- Copy these files into the dedicated wiki repo (`<repo>.wiki.git`) via the GitHub UI (**Wiki** tab → **Add page**) or by cloning the wiki repo and pushing.
- Use `Home.md` as the main entry page.
