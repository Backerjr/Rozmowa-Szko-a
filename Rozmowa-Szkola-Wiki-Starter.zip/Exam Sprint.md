# Exam Sprint

**Target:** ósmoklasisty / matura.  
**Structure (8 weeks):**
- Week 1–2: Listening + vocab for tasks
- Week 3–4: Reading / grammar-in-use
- Week 5–6: Speaking drills (cards)
- Week 7: Writing tasks (emails, descriptions)
- Week 8: Full mock + feedback

**Resources**
- Task bank (internal)
- Checklists per skill
- Parent progress notes template
