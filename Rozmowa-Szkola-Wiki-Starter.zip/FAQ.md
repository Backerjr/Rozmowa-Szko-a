# FAQ

**Q: Czy to kurs dla początkujących?**  
A: Tak, mamy ścieżkę A0–B1 w małych grupach.

**Q: Czy pomagacie w egzaminach?**  
A: Tak, 8-tygodniowy Sprint z mockami i feedbackiem.

**Q: Czy mogę przyjść z koleżanką/kolegą?**  
A: Jasne — Buddy Pass daje −10% dla obojga.
