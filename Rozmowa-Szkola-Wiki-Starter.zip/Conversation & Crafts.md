# Conversation & Crafts

**Format (120')**
- 0–10' Welcome & topic phrases
- 10–70' Conversation tasks (pairs/rotations)
- 70–115' Hands-on craft
- 115–120' Photo & RSVP for next session

**Examples**
- Bracelet / macramé night
- Seasonal decorations
- Postcard & calligraphy basics
