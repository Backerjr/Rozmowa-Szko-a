# About ROZMOWA

- **What we are:** A friendly, stress-free, conversation-first language space.
- **Where:** Pilchowice, Rynek 9.
- **Why we exist:** Help people speak naturally, not perfectly.
- **How we work:** Small groups, practical language, community vibe (coffee & crafts).
