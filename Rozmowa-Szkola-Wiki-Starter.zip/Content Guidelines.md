# Content Guidelines

**Reels (15–30')**
- Hook: everyday phrase/mini-problem
- Show: example in context
- Ask: save/share/comment
- CTA: trial or Starter Pack

**Captions**
- Plain Polish + short English phrase
- 1 call-to-action max

**Consent & Privacy**
- Written consent for any student appearance.
